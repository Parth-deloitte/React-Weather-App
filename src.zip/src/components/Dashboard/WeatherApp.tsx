import React, { useState } from "react";

import "./WeatherApp.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSearch } from "@fortawesome/free-solid-svg-icons";

import DefaultWatchlist from "./DefaultWatchlist";
import axios from "axios";

import { WeatherData } from "../weatherTypes";
import WeatherCard from "./WeatherCard";

const WeatherApp = () => {
  const [city, setCity] = useState<string>("");
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setCity(event.target.value);
  };

  const fetchData = async () => {
    try {
      const response = await axios.get<WeatherData>(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=f5427a0f5207b76cb82078bf8d15c9cb`
      );
      // console.log(response.data);
      setWeatherData(response.data);
    } catch (error) {
      console.error("Error fetching weather data:", error);
      setWeatherData(null);
    }
  };

  const handleIconClick = () => {
    fetchData();
  };

  return (
    <div className="weather-container">
      <div className="input-feild">
        <input
          className="location"
          type="text"
          value={city}
          onChange={handleInputChange}
          placeholder="Search Location"
        />
        <button className="search-btn" onClick={handleIconClick}>
          <FontAwesomeIcon icon={faSearch} />
        </button>
      </div>

      <div className="display-section">
        {weatherData ? (
          <WeatherCard data={weatherData} />
        ) : (
          <DefaultWatchlist />
        )}
      </div>
    </div>
  );
};

export default WeatherApp;
