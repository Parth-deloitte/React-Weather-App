import React, { useEffect, useState } from "react";
import "./WeatherDetails.css";
import { WeatherData } from "../weatherTypes";
import { useParams } from "react-router-dom";
import axios from "axios";
import vector from "../../assets/Vector.png";
import degree from "../../assets/degree.png";

const WeatherDetails: React.FC = () => {
  const { name } = useParams<{ name?: string }>();
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);

  const [lengthOfDay, setLengthOfDay] = useState("");
  const [daylightRemaining, setDaylightRemaining] = useState("");

  const calculateDayLight = () => {
    if (weatherData) {
      const sunrise = weatherData.sys.sunrise;
      const sunset = weatherData.sys.sunset;

      const sunriseTime: Date = new Date(sunrise * 1000);
      const sunsetTime: Date = new Date(sunset * 1000);

      const length: number =
        (sunsetTime.getTime() - sunriseTime.getTime()) / 1000; // Length of day in seconds

      const hours = Math.floor(length / 3600);
      const minutes = Math.floor((length % 3600) / 60);

      setLengthOfDay(`${hours}H ${minutes}M`);
    } else console.log(weatherData);
  };
  const fetchWeatherData = async (cityId: String) => {
    try {
      const response = await axios.get<WeatherData>(
        `https://api.openweathermap.org/data/2.5/weather?q=${cityId}&appid=f5427a0f5207b76cb82078bf8d15c9cb`
      );

      setWeatherData(response.data);
      console.log(response.data);
    } catch (error) {
      console.error("Error fetching weather data:", error);
      setWeatherData(null);
    }
  };

  useEffect(() => {
    console.log(name);
    // const cityId = parseInt(id ?? "", 10); // Use empty string as default value
    if (name !== undefined) {
      fetchWeatherData(name);
      calculateDayLight();
    }
  }, [name]);

  if (!weatherData) {
    return <div>Loading...</div>;
  }

  const temperatureInCelsius = Math.round(weatherData.main.temp - 273.15);
  const imgUrl = `https://openweathermap.org/img/wn/${weatherData.weather[0].icon}@2x.png`;

  return (
    <div className="weather-details-container">
      <div className="header-details">
        <img
          className="city-weather-img"
          src={imgUrl}
          alt={weatherData.weather[0].description}
        ></img>
        <div className="city-details">
          <p className="city-name">{weatherData.name}</p>
          <img src={vector} alt="vector" />
        </div>
        <div className="temp-details">
          <p className="temp-value">{temperatureInCelsius}</p>
          <img src={degree} alt="degree" />
        </div>
      </div>

      <div className="section-details">
        <div className="time-details">
          <p>TIME</p>
          <p> 11:07 A.M</p>
        </div>
        <div className="pressure-details">
          <p>PRESSURE</p>
          <p>963</p>
        </div>
        <div className="rain-details">
          <p>%RAIN</p>
          <p>58%</p>
        </div>
        <div className="humidity-details">
          <p>HUMIDITY</p>
          <p>22</p>
        </div>
      </div>

      <div className="footer-details">
        <div className="day-details">
          <p className="day-heading">SUNRISE & SUNSET</p>
          <div className="day-data">
            <div className="day-length">
              <p className="day-heading">Length of day:</p>
              <p className="day-value">{lengthOfDay}</p>
            </div>
            <div className="day-remain">
              <p className="day-heading">Remaining daylight:</p>
              <p className="day-value">9H 22M</p>
            </div>
          </div>
        </div>
        <div className="day-graph"> Hello</div>
      </div>
    </div>
  );
};

export default WeatherDetails;
